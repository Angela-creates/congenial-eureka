# SME Construction Platform (Prototype)

This project is a React-based one-stop platform for SME construction companies featuring:
- Rule-based chatbot (Inga)
- Jurisdiction & language selector
- Compliance dashboard with PDF uploads
- Feedback submission system

## 🚀 How to Run

1. Navigate to the folder:
   ```bash
   cd sme_construction_platform
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm start
   ```

## 📁 Structure

- `/src/SMEPlatform.js` — main application
- `/components/ui/` — input, button, select, textarea components

## 🛠 Future Features
- Google Translate API integration
- Live chatbot backend
- Compliance data persistence
